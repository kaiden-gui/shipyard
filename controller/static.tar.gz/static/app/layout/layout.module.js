(function(){
	'use strict';

	angular
		.module('shipyard.layout', [
			'ui.router'
		]);
		
})();
