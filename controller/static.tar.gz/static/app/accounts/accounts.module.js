(function(){
	'use strict';

	angular
		.module('shipyard.accounts', [
                        'ngResource',
			'ui.router',
		]);
		
})();
