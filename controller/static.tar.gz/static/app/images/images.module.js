(function(){
	'use strict';

	angular
		.module('shipyard.images', [
                    'ngResource',
                    'ui.router',
		]);
		
})();
