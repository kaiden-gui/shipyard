(function(){
	'use strict';

	angular
		.module('shipyard.help', [
			'ui.router'
		]);
		
})();
