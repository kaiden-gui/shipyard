(function(){
	'use strict';

	angular
		.module('shipyard.nodes', [
                        'ngResource',
			'ui.router',
		]);
		
})();
