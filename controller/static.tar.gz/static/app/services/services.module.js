(function(){
	'use strict';

	angular
		.module('shipyard.services', [
		]);
		
})();


