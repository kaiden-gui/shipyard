(function(){
	'use strict';

	angular
		.module('shipyard.login', [
            'shipyard.services',
			'ngResource',
			'ui.router'
		]);
		
})();

