(function(){
    'use strict';

    angular
        .module('shipyard.containers', [
                'shipyard.layout',
                'ngResource',
                'ngSanitize',
                'ui.router',
                'angularify.semantic.dropdown'
        ]);

})();
