(function(){
	'use strict';

	angular
		.module('shipyard.registry', [
                        'ngResource',
			'ui.router',
		]);
		
})();
