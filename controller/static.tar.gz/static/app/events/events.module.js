(function(){
	'use strict';

	angular
		.module('shipyard.events', [
                        'ngResource',
			'ui.router',
		]);
		
})();
